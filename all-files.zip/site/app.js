/* Report front-end — fetches data.json and renders KPIs / charts / tables. */
const fmtPct = (v, d=2) => (v == null || Number.isNaN(v) ? '—' : `${(v*100).toFixed(d)}%`);
const fmtPctRaw = (v, d=2) => (v == null || Number.isNaN(v) ? '—' : `${v.toFixed(d)}%`);
const fmtNum = (v, d=2) => (v == null || Number.isNaN(v) ? '—' : v.toFixed(d));
const fmtMoney = (v, d=0) =>
  v == null ? '—' : '$' + v.toLocaleString(undefined, {maximumFractionDigits: d, minimumFractionDigits: d});

const KPIS = [
  ['Total return',   d => fmtPct(d.total_return),   d => d.total_return >= 0],
  ['Annual return',  d => fmtPct(d.annual_return),  d => d.annual_return >= 0],
  ['Sharpe ratio',   d => fmtNum(d.sharpe_ratio),   d => d.sharpe_ratio >= 1],
  ['Max drawdown',   d => fmtPct(d.max_drawdown),   d => d.max_drawdown > -0.2],
  ['Win rate',       d => fmtPct(d.win_rate, 1),    d => d.win_rate >= 0.5],
  ['Profit factor',  d => fmtNum(d.profit_factor),  d => d.profit_factor >= 1.5],
  ['Total trades',   d => String(d.total_trades),   _ => true],
  ['Final balance',  d => fmtMoney(d.final_balance),d => d.final_balance >= d.starting_balance],
];

const METRIC_TABLE = [
  ['Starting balance',  d => fmtMoney(d.starting_balance), ''],
  ['Final balance',     d => fmtMoney(d.final_balance), 'after fees & slippage'],
  ['Total return',      d => fmtPct(d.total_return), 'cumulative over the period'],
  ['Annual return',     d => fmtPct(d.annual_return), 'CAGR'],
  ['Sharpe ratio',      d => fmtNum(d.sharpe_ratio), 'risk-free rate = 0'],
  ['Sortino ratio',     d => fmtNum(d.sortino_ratio), 'downside-only volatility'],
  ['Calmar ratio',      d => fmtNum(d.calmar_ratio), 'annual return ÷ |max drawdown|'],
  ['Max drawdown',      d => fmtPct(d.max_drawdown), 'worst peak-to-trough decline'],
  ['Profit factor',     d => fmtNum(d.profit_factor), 'gross profit ÷ gross loss'],
  ['Win rate',          d => fmtPct(d.win_rate, 1), `${Math.round(d.win_rate * d.total_trades)} winners`],
  ['Loss rate',         d => fmtPct(d.loss_rate, 1), `${Math.round(d.loss_rate * d.total_trades)} losers`],
  ['Average win',       d => fmtMoney(d.average_win), ''],
  ['Average loss',      d => fmtMoney(d.average_loss), ''],
  ['Risk / reward',     d => fmtNum(d.risk_reward), 'avg-win ÷ |avg-loss|'],
  ['Total trades',      d => d.total_trades, ''],
  ['Longest win streak',  d => d.longest_win_streak, ''],
  ['Longest loss streak', d => d.longest_loss_streak, ''],
];

(async function init() {
  const data = await fetch('./data.json').then(r => r.json());
  document.getElementById('genDate').textContent = new Date().toISOString().slice(0,10);
  const b = data.best;
  document.getElementById('bestName').textContent = b.strategy;
  document.getElementById('bestParams').textContent = '(' +
    Object.entries(b.params).map(([k,v]) => `${k}=${v}`).join(', ') + ')';
  document.getElementById('asset').textContent = data.benchmark.asset;
  document.getElementById('period').textContent = `${data.benchmark.start} → ${data.benchmark.end}`;
  document.getElementById('bars').textContent = data.benchmark.bars;
  const bh = data.benchmark.buy_and_hold_return;
  const bhEl = document.getElementById('bh');
  bhEl.textContent = fmtPct(bh);
  bhEl.className = 'text-2xl font-semibold num ' + (bh >= 0 ? 'text-emerald-400' : 'text-rose-400');

  // KPIs
  const grid = document.getElementById('kpiGrid');
  const tpl = document.getElementById('kpiTpl');
  KPIS.forEach(([label, fn, good]) => {
    const node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector('div:nth-child(1)').textContent = label;
    const val = node.querySelector('div:nth-child(2)');
    val.textContent = fn(b);
    val.classList.add(good(b) ? 'text-emerald-300' : 'text-rose-300');
    grid.appendChild(node);
  });

  // Metric table
  const mb = document.getElementById('metricsBody');
  METRIC_TABLE.forEach(([k, fn, note]) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td class="px-4 py-2">${k}</td>
                    <td class="px-4 py-2 text-right num">${fn(b)}</td>
                    <td class="px-4 py-2 text-slate-500 hidden md:table-cell">${note}</td>`;
    mb.appendChild(tr);
  });

  // Strategy comparison
  const cb = document.getElementById('cmpBody');
  for (const [name, s] of Object.entries(data.strategies)) {
    const cls = s.total_return >= 0 ? 'text-emerald-300' : 'text-rose-300';
    cb.insertAdjacentHTML('beforeend',
      `<tr>
        <td class="px-4 py-2">${name}${name === b.strategy ? ' <span class="text-[10px] uppercase text-sky-400 ml-1">best</span>' : ''}</td>
        <td class="px-4 py-2 text-right num ${cls}">${fmtPct(s.total_return)}</td>
        <td class="px-4 py-2 text-right num">${fmtNum(s.sharpe_ratio)}</td>
        <td class="px-4 py-2 text-right num text-rose-300">${fmtPct(s.max_drawdown)}</td>
        <td class="px-4 py-2 text-right num">${fmtPct(s.win_rate, 1)}</td>
        <td class="px-4 py-2 text-right num">${fmtNum(s.profit_factor)}</td>
        <td class="px-4 py-2 text-right num">${s.total_trades}</td>
      </tr>`);
  }

  // Optimisation top-5
  const top = data.optimisation.top5;
  const colKeys = ['fast','slow','total_return','sharpe_ratio','max_drawdown','win_rate','total_trades','objective'];
  const colLabels = ['Fast EMA','Slow EMA','Return','Sharpe','Max DD','Win rate','Trades','Objective'];
  document.getElementById('optHead').innerHTML =
    colLabels.map((l,i) => `<th class="${i<2?'text-left':'text-right'} px-4 py-3">${l}</th>`).join('');
  const ob = document.getElementById('optBody');
  top.forEach(row => {
    const cells = colKeys.map((k,i) => {
      let v = row[k];
      if (k === 'total_return' || k === 'max_drawdown' || k === 'win_rate') v = fmtPct(v);
      else if (k === 'sharpe_ratio' || k === 'objective') v = fmtNum(v, 3);
      return `<td class="${i<2?'text-left':'text-right'} px-4 py-2 num">${v}</td>`;
    });
    ob.insertAdjacentHTML('beforeend', `<tr>${cells.join('')}</tr>`);
  });

  // Insights
  const il = document.getElementById('insightsList');
  (b.insights || []).forEach(t => {
    il.insertAdjacentHTML('beforeend',
      `<li class="flex gap-3 items-start rounded-lg border border-slate-800 bg-slate-900/30 p-3">
         <span class="text-sky-400 mt-0.5">▸</span>
         <span class="text-slate-200">${t.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>')}</span>
       </li>`);
  });

  // Trades
  document.getElementById('tradeCount').textContent = data.trades.length;
  const tb = document.getElementById('tradesBody');
  data.trades.forEach(t => {
    const cls = t.pnl >= 0 ? 'text-emerald-300' : 'text-rose-300';
    tb.insertAdjacentHTML('beforeend',
      `<tr class="hover:bg-slate-900/40">
        <td class="px-3 py-1.5">${t.entry}</td>
        <td class="px-3 py-1.5">${t.exit}</td>
        <td class="px-3 py-1.5 ${t.side==='long'?'text-emerald-400':'text-rose-400'}">${t.side}</td>
        <td class="px-3 py-1.5 text-right">${fmtMoney(t.entry_price, 2)}</td>
        <td class="px-3 py-1.5 text-right">${fmtMoney(t.exit_price, 2)}</td>
        <td class="px-3 py-1.5 text-right">${t.qty.toFixed(4)}</td>
        <td class="px-3 py-1.5 text-right ${cls}">${fmtMoney(t.pnl, 2)}</td>
        <td class="px-3 py-1.5 text-right ${cls}">${fmtPctRaw(t.pnl_pct)}</td>
        <td class="px-3 py-1.5 text-right">${t.score.toFixed(0)}</td>
        <td class="px-3 py-1.5 text-slate-400">${t.reason_exit}</td>
      </tr>`);
  });

  // Charts ---------------------------------------------------------------
  const dark = { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.08)' } };
  const baseOpts = {
    responsive: true, animation: false,
    plugins: { legend: { labels: { color: '#cbd5e1' } } },
    scales: { x: dark, y: dark },
  };

  new Chart(document.getElementById('equityChart'), {
    type: 'line',
    data: { datasets: [{
      label: 'Equity ($)',
      data: data.equity.map(p => ({x: p.t, y: p.v})),
      borderColor: '#38bdf8', backgroundColor: 'rgba(56,189,248,0.15)',
      fill: true, pointRadius: 0, borderWidth: 2, tension: 0.1,
    }]},
    options: { ...baseOpts, scales: { x: { type:'time', ...dark }, y: dark } },
  });

  new Chart(document.getElementById('ddChart'), {
    type: 'line',
    data: { datasets: [{
      label: 'Drawdown (%)',
      data: data.drawdown.map(p => ({x: p.t, y: p.v})),
      borderColor: '#f43f5e', backgroundColor: 'rgba(244,63,94,0.18)',
      fill: true, pointRadius: 0, borderWidth: 1.5,
    }]},
    options: { ...baseOpts, scales: { x: { type:'time', ...dark }, y: dark } },
  });

  new Chart(document.getElementById('monthlyChart'), {
    type: 'bar',
    data: { labels: data.monthly.map(m => m.m),
            datasets: [{
              label: 'Monthly %',
              data: data.monthly.map(m => m.r),
              backgroundColor: data.monthly.map(m => m.r >= 0 ? 'rgba(52,211,153,0.75)' : 'rgba(244,63,94,0.75)'),
            }] },
    options: baseOpts,
  });

  new Chart(document.getElementById('distChart'), {
    type: 'bar',
    data: {
      labels: ['<-20','-20..-10','-10..-5','-5..0','0..5','5..10','10..20','20..30','30..50','>50'],
      datasets: [{
        label: 'Trades',
        data: data.distribution,
        backgroundColor: ['#ef4444','#f97316','#f59e0b','#facc15','#a3e635','#84cc16','#22c55e','#10b981','#14b8a6','#06b6d4'],
      }],
    },
    options: baseOpts,
  });
})();
