# AI Crypto Backtest Engine

Production-ready backtesting engine for AI trading strategies on crypto markets.
Built entirely on **free-tier APIs** (Binance, CoinGecko, Bitget, CryptoPanic,
Alternative.me, DefiLlama, GeckoTerminal) and open-source tooling.

- **Backend**: FastAPI + pandas/numpy event-driven engine
- **Frontend**: Next.js 14 (App Router) + Tailwind + shadcn/ui + TradingView Lightweight Charts
- **Database**: Supabase (Postgres, RLS-enabled schema included)
- **Hosting**: Vercel (frontend) + Railway/Render (backend)
- **CI/CD**: GitHub Actions (lint, tests, Docker images)

---

## Features

- Multi-factor AI scoring engine combining RSI, MACD, EMA trend, volume,
  momentum, Fear & Greed and news sentiment into a 0-100 buy/hold/sell score
- Plug-in strategy registry — drop a file in `backend/app/strategies/`
- Realistic backtest with fees, slippage, stop-loss, take-profit, trailing
  stop, leverage, and risk-based position sizing
- 17 performance metrics including Sharpe, Sortino, Calmar, profit factor,
  drawdown, win-rate, streaks
- Equity, drawdown, monthly-returns and trade-distribution charts
- Side-by-side strategy comparison
- Parameter grid-search optimisation (objectives: Sharpe / Calmar / Return)
- Rule-based AI insights ("strategy performs best in bullish markets…")
- CSV / JSON trade-log export
- On-disk gzip-Parquet cache so historical data is downloaded once
- Pluggable broker interface — same strategy runs in backtest, paper, or live
  (Bitget adapter included as a stub)
- Telegram / Discord alert adapters

## Project layout

```
crypto-backtest-engine/
├── backend/                      FastAPI service
│   ├── app/
│   │   ├── api/                  REST routers (data, strategies, backtests, insights)
│   │   ├── core/                 settings + on-disk cache
│   │   ├── data/                 providers (binance, coingecko, bitget, cryptopanic, …)
│   │   ├── db/                   schema.sql + Supabase REST client
│   │   ├── engine/               event-driven backtest engine + metrics
│   │   ├── indicators/           RSI, EMA, MACD, BB, ATR, VWAP, StochRSI, …
│   │   ├── insights/             rule-based insight generator
│   │   ├── optimization/         grid-search optimiser
│   │   ├── strategies/           plug-in strategies (ai_scoring, ema_cross, rsi_meanrev)
│   │   ├── trading/              broker interface + paper + bitget_live
│   │   └── alerts/               telegram + discord
│   ├── scripts/run_demo.py       end-to-end demo runner
│   ├── tests/                    pytest suite
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                     Next.js 14 app
│   ├── app/                      pages: dashboard, strategies, backtests, compare, optimise
│   ├── components/               UI + charts + tables
│   ├── lib/                      typed API client + utils
│   └── Dockerfile
├── data/                         sample BTCUSDT 5y daily OHLCV (Binance)
├── docker-compose.yml            backend + frontend
├── .github/workflows/ci.yml      lint, tests, Docker builds
└── .env.example                  all configurable knobs
```

## Quick start

```bash
git clone <repo> && cd crypto-backtest-engine
cp .env.example .env             # all keys optional, defaults work for backtesting

# --- backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload    # http://localhost:8000/docs

# --- frontend (in another shell)
cd frontend
npm install
npm run dev                       # http://localhost:3001
```

Run the bundled demo to produce a full report from real BTC data:

```bash
cd backend
python -m scripts.run_demo        # writes output/demo/{metrics.json,trades.csv,equity.csv}
```

Run the test suite:

```bash
cd backend && pytest -q           # 21 tests
```

Or run everything in Docker:

```bash
docker compose up --build         # backend :8000 + frontend :3001
```

## Free-tier data sources

| Source                       | Used for                          | Auth      |
|------------------------------|-----------------------------------|-----------|
| Binance public REST          | OHLCV (1m → 1w)                   | None      |
| CoinGecko free               | Long-history OHLC for any coin    | None      |
| Bitget public                | Backup OHLCV + future live broker | None      |
| Alternative.me               | Crypto Fear & Greed index         | None      |
| CryptoPanic                  | News + coarse sentiment           | Free key  |
| DefiLlama                    | TVL / on-chain context            | None      |
| GeckoTerminal                | DEX OHLCV for long-tail tokens    | None      |

## Strategy plug-in API

A strategy is any object with `name`, `params`, `prepare(df)` and
`decide(row, position) → Signal`.  Register it with `@register("my_name")`.
See `backend/app/strategies/ema_cross.py` for a 30-line example.

## Deployment

See [`DEPLOY.md`](./DEPLOY.md) for one-click Vercel + Railway + Supabase
instructions.

## Live trading roadmap

The same strategies run unchanged against:

- `app.trading.paper.PaperBroker`           (forward-test on live prices)
- `app.trading.bitget_live.BitgetLiveBroker` (real funds — opt-in)
- `app.alerts.broadcast(...)`                (Telegram / Discord)

Only the broker swaps.  Engine, indicators, scoring and metrics are
unchanged.

## License

MIT
